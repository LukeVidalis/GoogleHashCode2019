
public class Values {

	protected static final String a = "InputFiles/a_example.txt";
	protected static final String b = "InputFiles/b_lovely_landscapes.txt";
	protected static final String c = "InputFiles/c_memorable_moments.txt";
	protected static final String d = "InputFiles/d_pet_pictures.txt";
	protected static final String e = "InputFiles/e_shiny_selfies.txt";

}
